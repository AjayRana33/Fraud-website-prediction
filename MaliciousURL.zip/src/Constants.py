serverName = "WISEN\SQLEXPRESS"
databaseName = "PhishingWebsiteDetection05"
connString = 'Driver={SQL Server};Server='+serverName+';Integrated_Security=true;Database='+databaseName